var counter=function(arr){
    return "the num of element is :" + arr.length;
}
var add=function(a,b){
    return a+b
}

var pi=3.14;

module.exports={
    counter:counter,
    add:add,
    pi:pi
}