const { run } = require('./gemini');
const express = require('express');
const cors = require("cors");


const app = express();
const port = 3002;
app.use(cors()); 
app.use(express.json());

app.post('/api/control', async (req, res) => {
  try {
    console.log(req.body);
    const message = req.body.message;
    const result = await run(message);
    console.log('Received message:', message);
    console.log(result);
    res.json({ message: result });
  } catch (error) {
    console.error("Error occurred in API control endpoint:", error);
    res.status(500).json({ error: "Internal server error" });
  }
});

app.listen(port, () => {
  console.log(`Server is running on http://localhost:${port}`);
});
  
